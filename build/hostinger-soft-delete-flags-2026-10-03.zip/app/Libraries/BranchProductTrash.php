<?php

namespace App\Libraries;

use CodeIgniter\Database\BaseConnection;

final class BranchProductTrash
{
    public function __construct(private BaseConnection $db) {}

    public function change(int $productId, int $branchId, bool $trash, string $role, int $userId): bool
    {
        if ($role !== 'admin') {
            throw new \DomainException('Only administrators can move or restore branch products.');
        }
        if ($productId <= 0 || $branchId <= 0 || $userId <= 0) {
            throw new \InvalidArgumentException('Select a specific branch product before changing its trash status.');
        }
        $this->db->transBegin();
        try {
            $row = $this->db->query('SELECT * FROM branch_products WHERE product_id = ? AND branch_id = ? FOR UPDATE', [$productId, $branchId])->getRowArray();
            $product = $this->db->query('SELECT * FROM products WHERE id = ? FOR UPDATE', [$productId])->getRowArray();
            $branch = $this->db->table('branches')->where('id', $branchId)->get()->getRowArray();
            if (!$row || !$product || !$branch) {
                throw new \InvalidArgumentException('This product does not have an inventory record in the selected branch.');
            }
            if (!empty($product['deleted_at']) || !empty($product['is_deleted'])) {
                throw new \InvalidArgumentException('This is an older shared product deletion. Use the legacy restore action in Product Trash first.');
            }
            if ($trash === (!empty($row['deleted_at']) || !empty($row['is_deleted']))) {
                $this->db->transCommit();
                return false;
            }
            $now = date('Y-m-d H:i:s');
            $this->write($this->db->table('branch_products')->where('id', $row['id'])->update([
                'is_deleted' => $trash ? 1 : 0,
                'deleted_at' => $trash ? $now : null, 'updated_at' => $now,
            ]));
            $action = $trash ? 'Moved to Trash' : 'Restored from Trash';
            $this->write($this->db->table('stock_logs')->insert([
                'product_id'=>$productId, 'branch_id'=>$branchId, 'user_id'=>$userId,
                'action_type'=>'adjustment', 'quantity'=>0,
                'previous_stock'=>(int)$row['stock'], 'new_stock'=>(int)$row['stock'],
                'remarks'=>'Branch product: ' . $action . '; stock and prices retained.', 'created_at'=>$now,
            ]));
            $this->write($this->db->table('activity_logs')->insert([
                'user_id'=>$userId, 'activity'=>$action . ': product #' . $productId . ' in branch #' . $branchId,
                'log_time'=>$now,
            ]));
            if (!$this->db->transStatus()) throw new \RuntimeException('The branch product change could not be saved.');
            $this->db->transCommit();
            return true;
        } catch (\Throwable $error) {
            $this->db->transRollback();
            throw $error;
        }
    }

    private function write(bool $ok): void
    {
        if (!$ok) throw new \RuntimeException('The branch product change could not be saved.');
    }
}
