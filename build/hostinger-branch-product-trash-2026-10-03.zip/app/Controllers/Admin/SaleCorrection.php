<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\SalesModel;
use App\Models\SaleItemModel;
use App\Models\ActivityLogModel;
use App\Models\StockLogModel;
use App\Models\BranchProductModel;

class SaleCorrection extends BaseController
{
    protected SalesModel $salesModel;
    protected SaleItemModel $saleItemModel;
    protected ActivityLogModel $activityLogModel;
    protected StockLogModel $stockLogModel;
    protected BranchProductModel $branchProductModel;
    protected $db;

    public function __construct()
    {
        $this->salesModel = new SalesModel();
        $this->saleItemModel = new SaleItemModel();
        $this->activityLogModel = new ActivityLogModel();
        $this->stockLogModel = new StockLogModel();
        $this->branchProductModel = new BranchProductModel();
        $this->db = \Config\Database::connect();
    }

    public function edit(int $saleId)
    {
        $sale = $this->getSaleWithDetails($saleId);
        if (!$sale) {
            return redirect()->to(site_url('cashier/sales/history'))->with('error', 'Sale record not found.');
        }
        if (!$this->canCorrect($sale)) {
            return redirect()->to(site_url('cashier/sales/history'))
                ->with('error', 'Only completed sales without refunds or exchange links can be corrected.');
        }

        return $this->renderCorrection($sale);
    }

    public function update(int $saleId)
    {
        $sale = $this->getSaleWithDetails($saleId);
        if (!$sale) {
            return redirect()->to(site_url('cashier/sales/history'))->with('error', 'Sale record not found.');
        }
        if (!$this->canCorrect($sale)) {
            return redirect()->to(site_url('cashier/sales/history'))
                ->with('error', 'Only completed sales without refunds or exchange links can be corrected.');
        }

        $rules = [
            'correction_reason' => 'required|min_length[5]|max_length[500]',
            'notes' => 'permit_empty|max_length[500]',
            'payment_method' => 'required|in_list[cash,gcash,card]',
            'reference_no' => 'permit_empty|max_length[100]',
        ];
        if (!$this->validateData($this->request->getPost(), $rules)) {
            return $this->renderCorrection($sale, $this->validator);
        }

        $postedItems = $this->request->getPost('items');
        if (!is_array($postedItems)) {
            $postedItems = [];
        }
        foreach ($postedItems as $qty) {
            if (!is_numeric($qty) || filter_var($qty, FILTER_VALIDATE_INT) === false || (int) $qty < 0) {
                return $this->renderCorrection($sale, null, 'All corrected quantities must be whole numbers of 0 or greater.');
            }
        }

        $newPaymentMethod = trim((string) $this->request->getPost('payment_method'));
        $newReferenceNo = trim((string) ($this->request->getPost('reference_no') ?? ''));
        if ($newPaymentMethod === 'cash') {
            $newReferenceNo = '';
        }

        $this->db->transStart();

        // Lock the sale so a refund cannot be processed while an administrator
        // is correcting the same transaction in another browser session.
        $lockedSale = $this->db->query(
            'SELECT * FROM sales WHERE id = ? FOR UPDATE',
            [$saleId]
        )->getRowArray();
        $hasRefunds = $this->db->table('refund_items')->where('sale_id', $saleId)->countAllResults() > 0;
        if (!$lockedSale || $lockedSale['status'] !== 'completed' || $hasRefunds) {
            $this->db->transRollback();
            return redirect()->to(site_url('cashier/sales/history'))
                ->with('error', 'This sale changed while the correction page was open. Review its latest status before trying again.');
        }

        $sale = array_replace($sale, $lockedSale);
        $currentItems = $this->db->query(
            'SELECT * FROM sale_items WHERE sale_id = ? ORDER BY id FOR UPDATE', [$saleId]
        )->getResultArray();
        if (!hash_equals(\App\Libraries\SaleRevision::fingerprint($sale, $currentItems), (string) $this->request->getPost('sale_revision'))) {
            $this->db->transRollback();
            return redirect()->to(site_url('admin/sale-correction/' . $saleId))
                ->with('error', 'This sale was changed by another request. Review the latest values before saving again.');
        }
        $rejectCorrection = function (array $sale, $validation, string $message) {
            $this->db->transRollback();
            return $this->renderCorrection($sale, $validation, $message);
        };

        $plans = [];
        $hasDiscount = \App\Libraries\DiscountPolicy::hasDiscount($sale, $currentItems);
        $newTotal = 0.0;
        $newDiscountAmount = 0.0;

        foreach ($currentItems as $item) {
            $itemId = (int) $item['id'];
            $oldQty = (int) $item['quantity'];
            $newQty = array_key_exists($itemId, $postedItems) ? (int) $postedItems[$itemId] : $oldQty;
            $qtyDiff = $newQty - $oldQty;
            if ($qtyDiff !== 0 && $hasDiscount) {
                return $rejectCorrection($sale, null, 'Use a refund and a new sale to change quantities on a discounted sale. Notes and payment details can still be corrected.');
            }

            $grossSubtotal = $hasDiscount ? (float) $item['subtotal'] : round((float) $item['price'] * $newQty, 2);
            $newItemDiscount = $hasDiscount ? (float) $item['discount_applied'] : 0.0;
            $newProfit = $hasDiscount ? (float) $item['profit'] : round($grossSubtotal - ((float) $item['cost_price_at_sale'] * $newQty), 2);

            $branchProduct = null;
            if ($qtyDiff !== 0) {
                $branchProduct = $this->branchProductModel
                    ->where('product_id', $item['product_id'])
                    ->where('branch_id', $sale['branch_id'])
                    ->first();

                if (!$branchProduct) {
                    return $rejectCorrection($sale, null, 'The branch inventory record for ' . $item['product_name_snapshot'] . ' was not found.');
                }
                if ($qtyDiff > 0 && (int) $branchProduct['stock'] < $qtyDiff) {
                    return $rejectCorrection(
                        $sale,
                        null,
                        'Not enough stock to increase ' . $item['product_name_snapshot'] . '. Available stock: ' . (int) $branchProduct['stock'] . '.'
                    );
                }
            }

            $plans[] = [
                'item' => $item,
                'old_qty' => $oldQty,
                'new_qty' => $newQty,
                'qty_diff' => $qtyDiff,
                'branch_product' => $branchProduct,
                'subtotal' => $grossSubtotal,
                'discount' => $newItemDiscount,
                'profit' => $newProfit,
            ];
            $newTotal += $grossSubtotal;
            $newDiscountAmount += $newItemDiscount;
        }

        $remainingQuantity = array_sum(array_map(static fn (array $plan): int => (int) $plan['new_qty'], $plans));
        if ($remainingQuantity <= 0) {
            return $rejectCorrection(
                $sale,
                null,
                'A completed sale must keep at least one item. Use the refund function when the entire sale needs to be reversed.'
            );
        }

        $newTotal = $hasDiscount ? (float) $sale['total_amount'] : round($newTotal, 2);
        $newDiscountAmount = $hasDiscount ? (float) $sale['discount_amount'] : round(min($newTotal, $newDiscountAmount), 2);
        $finalTotal = $hasDiscount ? (float) $sale['final_total'] : round(max(0, $newTotal - $newDiscountAmount), 2);
        if ($finalTotal > (float) $sale['amount_paid'] + 0.009) {
            return $rejectCorrection(
                $sale,
                null,
                'The corrected total is higher than the amount paid. Record the additional items as a new sale instead.'
            );
        }

        $correctionReason = trim((string) $this->request->getPost('correction_reason'));
        $newNotes = trim((string) ($this->request->getPost('notes') ?? ''));
        $userId = (int) session('user_id');
        $changes = [];
        $changedProductIds = [];

        if ((string) ($sale['notes'] ?? '') !== $newNotes) {
            $changes[] = 'Notes changed';
        }
        if ($sale['payment_method'] !== $newPaymentMethod) {
            $changes[] = 'Payment method: ' . $sale['payment_method'] . ' → ' . $newPaymentMethod;
        }
        if ((string) ($sale['reference_no'] ?? '') !== $newReferenceNo) {
            $changes[] = 'Payment reference updated';
        }

        foreach ($plans as $plan) {
            $item = $plan['item'];
            if ($plan['qty_diff'] !== 0) {
                $branchProduct = $this->db->query(
                    'SELECT * FROM branch_products WHERE id = ? AND branch_id = ? FOR UPDATE',
                    [(int) $plan['branch_product']['id'], (int) $sale['branch_id']]
                )->getRowArray();
                if (!$branchProduct) {
                    $this->db->transRollback();
                    return $this->renderCorrection($sale, null, 'The branch inventory record for ' . $item['product_name_snapshot'] . ' is no longer available.');
                }
                if ((int)$plan['qty_diff'] > 0 && !empty($branchProduct['deleted_at'])) {
                    $this->db->transRollback();
                    return $this->renderCorrection($sale, null, 'This product is in branch Trash. Restore it before increasing the sold quantity.');
                }
                if ((int) $plan['qty_diff'] > 0 && (int) $branchProduct['stock'] < (int) $plan['qty_diff']) {
                    $this->db->transRollback();
                    return $this->renderCorrection(
                        $sale,
                        null,
                        'Stock changed while this page was open. Available stock for ' . $item['product_name_snapshot'] . ': ' . (int) $branchProduct['stock'] . '.'
                    );
                }

                $previousStock = (int) $branchProduct['stock'];
                $adjustedStock = $previousStock - (int) $plan['qty_diff'];

                $this->branchProductModel->update((int) $branchProduct['id'], [
                    'stock' => $adjustedStock,
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
                $this->stockLogModel->insert([
                    'product_id' => $item['product_id'],
                    'branch_id' => $sale['branch_id'],
                    'user_id' => $userId,
                    'action_type' => 'adjustment',
                    'quantity' => abs((int) $plan['qty_diff']),
                    'previous_stock' => $previousStock,
                    'new_stock' => $adjustedStock,
                    'remarks' => 'Sale correction ' . $sale['invoice_no'] . ': qty ' . $plan['old_qty'] . ' → ' . $plan['new_qty'] . '. Reason: ' . $correctionReason,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
                $changedProductIds[(int) $item['product_id']] = true;
                $changes[] = '"' . $item['product_name_snapshot'] . '" qty: ' . $plan['old_qty'] . ' → ' . $plan['new_qty'];
            }

            $this->saleItemModel->update((int) $item['id'], [
                'quantity' => $plan['new_qty'],
                'subtotal' => $plan['subtotal'],
                'discount_applied' => $plan['discount'],
                'profit' => $plan['profit'],
            ]);
        }

        foreach (array_keys($changedProductIds) as $productId) {
            $this->syncMasterStock((int) $productId);
        }

        $this->salesModel->update($saleId, [
            'notes' => $newNotes !== '' ? $newNotes : null,
            'payment_method' => $newPaymentMethod,
            'reference_no' => $newReferenceNo !== '' ? $newReferenceNo : null,
            'total_amount' => $newTotal,
            'discount_amount' => $newDiscountAmount,
            'final_total' => $finalTotal,
            'change_amount' => round(max(0, (float) $sale['amount_paid'] - $finalTotal), 2),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        $this->db->transComplete();
        if ($this->db->transStatus() === false) {
            return redirect()->back()->withInput()->with('error', 'Correction failed. No changes were saved.');
        }

        $changeSummary = $changes ? implode('; ', $changes) : 'No value changed (reason recorded only)';
        $this->activityLogModel->insert([
            'user_id' => $userId,
            'activity' => 'Sale correction: INV#' . $sale['invoice_no'] . ' | ' . $changeSummary . ' | Reason: ' . $correctionReason,
            'log_time' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(site_url('admin/sale-correction/' . $saleId))
            ->with('success', 'Sale corrected and recorded in the activity log.');
    }

    private function renderCorrection(array $sale, $validation = null, ?string $itemError = null)
    {
        return view('admin/sale_correction/edit', [
            'sale' => $sale,
            'items' => $this->saleItemModel->where('sale_id', $sale['id'])->findAll(),
            'correctionHistory' => $this->getCorrectionHistory($sale['invoice_no']),
            'validation' => $validation ?? \Config\Services::validation(),
            'itemError' => $itemError,
        ]);
    }

    private function canCorrect(array $sale): bool
    {
        if (\App\Libraries\ExchangeRecord::identity($sale)) return false;
        if (($sale['status'] ?? '') !== 'completed' || empty($sale['id'])) {
            return false;
        }

        return $this->db->table('refund_items')
            ->where('sale_id', (int) $sale['id'])
            ->countAllResults() === 0;
    }

    private function syncMasterStock(int $productId): void
    {
        $row = $this->db->table('branch_products')
            ->selectSum('stock', 'total_stock')
            ->where('product_id', $productId)
            ->get()
            ->getRowArray();

        $this->db->table('products')->where('id', $productId)->update([
            'stock' => (int) ($row['total_stock'] ?? 0),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
    }

    private function getSaleWithDetails(int $saleId): ?array
    {
        return $this->salesModel
            ->select('sales.*, users.full_name, branches.branch_name')
            ->join('users', 'users.id = sales.user_id', 'left')
            ->join('branches', 'branches.id = sales.branch_id', 'left')
            ->where('sales.id', $saleId)
            ->first();
    }

    private function getCorrectionHistory(string $invoiceNo): array
    {
        return $this->activityLogModel
            ->select('activity_logs.*, users.full_name, users.username')
            ->join('users', 'users.id = activity_logs.user_id', 'left')
            ->like('activity_logs.activity', 'Sale correction: INV#' . $invoiceNo)
            ->orderBy('activity_logs.id', 'DESC')
            ->findAll();
    }
}
