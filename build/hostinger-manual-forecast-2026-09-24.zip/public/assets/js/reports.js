(() => {
    const root = document.querySelector('.reports-workspace');
    if (!root) return;
    const forms = [...root.querySelectorAll('#salesReportFilters, #salesForecastFilters')];
    const serialize = form => new URLSearchParams(new FormData(form)).toString();
    const original = forms.map(serialize);
    const notice = document.getElementById('reportPendingFilters');
    const forecastNotice = document.getElementById('forecastPendingFilters');
    const updatePending = () => {
        notice.hidden = forms.every((form, index) => serialize(form) === original[index]);
        const index = forms.findIndex(form => form.id === 'salesForecastFilters');
        if (forecastNotice && index !== -1) forecastNotice.hidden = serialize(forms[index]) === original[index];
    };
    forms.forEach(form => {
        form.addEventListener('input', updatePending);
        form.addEventListener('change', updatePending);
    });

    const from = document.getElementById('reportDateFrom');
    const to = document.getElementById('reportDateTo');
    const presets = root.querySelector('.rp-date-presets');
    const buttons = [...presets.querySelectorAll('button')];
    const formatDate = date => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
    const range = type => {
        const end = new Date(presets.dataset.today + 'T12:00:00');
        const start = new Date(end);
        if (type === 'month') start.setDate(1);
        else if (type !== 'today') start.setDate(start.getDate() - Number(type) + 1);
        return [formatDate(start), formatDate(end)];
    };
    const updatePresets = () => buttons.forEach(button => {
        const [start, end] = range(button.dataset.reportRange);
        button.setAttribute('aria-pressed', String(from.value === start && to.value === end));
    });
    buttons.forEach(button => button.addEventListener('click', () => {
        [from.value, to.value] = range(button.dataset.reportRange);
        [from, to].forEach(input => input.dispatchEvent(new Event('change', {bubbles:true})));
        updatePresets();
    }));
    [from, to].forEach(input => input.addEventListener('change', updatePresets));
    updatePresets();
})();
