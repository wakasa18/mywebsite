<?= $this->extend('layouts/staff') ?>
<?= $this->section('content') ?>

<div class="page-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:20px;">
    <div>
        <h1>🗑 Product Trash</h1>
        <p>Soft-deleted products — restore or permanently remove them.</p>
    </div>
    <a href="<?= site_url('products') ?>" class="btn btn-secondary">← Back to Products</a>
</div>

<?php if (session()->getFlashdata('success')): ?>
    <div class="alert success"><?= esc(session()->getFlashdata('success')) ?></div>
<?php endif; ?>
<?php if (session()->getFlashdata('error')): ?>
    <div class="alert error"><?= esc(session()->getFlashdata('error')) ?></div>
<?php endif; ?>

<!-- Search bar -->
<form method="get" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px;">
    <input type="text" name="keyword" class="input" style="max-width:300px;"
        placeholder="Search by name or SKU…" value="<?= esc($keyword) ?>">
    <button type="submit" class="btn btn-primary">Search</button>
    <a href="<?= site_url('products/trash') ?>" class="btn btn-secondary">Reset</a>
</form>

<div class="card">
    <div class="table-wrap">
        <table class="mobile-record-table" data-record-title="1" aria-label="Deleted products">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Product Name</th>
                    <th>SKU</th>
                    <th>Category</th>
                    <th>Supplier</th>
                    <th>Deleted At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($products)): ?>
                    <?php foreach ($products as $i => $p): ?>
                    <tr>
                        <td class="muted" style="font-size:13px;"><?= $i + 1 ?></td>
                        <td style="font-weight:700;font-size:15px;"><?= esc($p['product_name']) ?></td>
                        <td style="font-family:'DM Mono',monospace;font-size:13px;"><?= esc($p['sku'] ?: '—') ?></td>
                        <td><?= esc($p['category_name'] ?? '—') ?></td>
                        <td><?= esc($p['supplier_name'] ?? '—') ?></td>
                        <td style="font-size:13px;color:var(--muted);"><?= esc($p['deleted_at']) ?></td>
                        <td>
                            <div style="display:flex;gap:6px;">
                                <form method="post" action="<?= site_url('products/restore/' . $p['id']) ?>" class="inline-action-form" onsubmit="return confirm('Restore this product?');">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="btn btn-sm btn-secondary" data-busy-label="Restoring…">Restore</button>
                                </form>
                                <form method="post" action="<?= site_url('products/force-delete/' . $p['id']) ?>" class="inline-action-form" onsubmit="return confirm('Permanently delete this product? This cannot be undone.');">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="btn btn-sm btn-danger" data-busy-label="Deleting…">Delete Forever</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--muted);">Trash is empty.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if (!empty($pager)): ?>
    <div class="paginationWrap">
        <?= $pager->links() ?>
    </div>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
