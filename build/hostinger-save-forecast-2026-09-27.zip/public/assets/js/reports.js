(() => {
    const root = document.querySelector('.reports-workspace');
    if (!root) return;
    const forms = [...root.querySelectorAll('#salesReportFilters, #salesForecastFilters')];
    const serialize = form => new URLSearchParams(new FormData(form)).toString();
    const original = forms.map(serialize);
    const notice = document.getElementById('reportPendingFilters');
    const forecastNotice = document.getElementById('forecastPendingFilters');
    const updatePending = () => {
        notice.hidden = forms.every((form, index) => serialize(form) === original[index]);
        const index = forms.findIndex(form => form.id === 'salesForecastFilters');
        if (forecastNotice && index !== -1) forecastNotice.hidden = serialize(forms[index]) === original[index];
    };
    forms.forEach(form => {
        form.addEventListener('input', updatePending);
        form.addEventListener('change', updatePending);
    });

    // Keep the forecast section at its previous viewport position after POST/redirect/GET.
    const forecastForm = document.getElementById('salesForecastFilters');
    const scrollKey = 'reports:forecast-scroll';
    const sortedQuery = value => {
        const params = new URLSearchParams(value);
        const filters = ['branch_id', 'report_type', 'report_date_from', 'report_date_to', 'forecast_type', 'forecast_date_from', 'forecast_date_to'];
        [...params.keys()].forEach(key => { if (!filters.includes(key)) params.delete(key); });
        params.sort();
        return params.toString();
    };
    if (forecastForm) {
        window.addEventListener('pageshow', () => {
            const button = forecastForm.querySelector('button[type="submit"]');
            if (button && button.dataset.originalLabel) {
                button.disabled = false;
                button.textContent = button.dataset.originalLabel;
            }
        });
        forecastForm.addEventListener('submit', () => {
            try {
                sessionStorage.setItem(scrollKey, JSON.stringify({
                    path: new URL(forecastForm.dataset.returnUrl || forecastForm.action, location.href).pathname,
                    query: sortedQuery(new FormData(forecastForm)),
                    top: forecastForm.getBoundingClientRect().top,
                    x: window.scrollX,
                    time: Date.now()
                }));
            } catch (_) { /* Submission still works when storage is unavailable. */ }
        });
        try {
            const saved = JSON.parse(sessionStorage.getItem(scrollKey) || 'null');
            sessionStorage.removeItem(scrollKey);
            if (saved && saved.path === location.pathname && saved.query === sortedQuery(location.search)
                && Date.now() - saved.time < 300000 && Number.isFinite(saved.top) && Number.isFinite(saved.x)) {
                const restore = async () => {
                    if (document.fonts) await document.fonts.ready;
                    requestAnimationFrame(() => {
                        window.scrollTo({
                            left: saved.x,
                            top: window.scrollY + forecastForm.getBoundingClientRect().top - saved.top,
                            behavior: 'instant'
                        });
                    });
                };
                if (document.readyState === 'complete') restore();
                else window.addEventListener('load', restore, {once: true});
            }
        } catch (_) { /* Ignore unavailable storage or an outdated saved position. */ }
    }

    const from = document.getElementById('reportDateFrom');
    const to = document.getElementById('reportDateTo');
    const presets = root.querySelector('.rp-date-presets');
    const buttons = [...presets.querySelectorAll('button')];
    const formatDate = date => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
    const range = type => {
        const end = new Date(presets.dataset.today + 'T12:00:00');
        const start = new Date(end);
        if (type === 'month') start.setDate(1);
        else if (type !== 'today') start.setDate(start.getDate() - Number(type) + 1);
        return [formatDate(start), formatDate(end)];
    };
    const updatePresets = () => buttons.forEach(button => {
        const [start, end] = range(button.dataset.reportRange);
        button.setAttribute('aria-pressed', String(from.value === start && to.value === end));
    });
    buttons.forEach(button => button.addEventListener('click', () => {
        [from.value, to.value] = range(button.dataset.reportRange);
        [from, to].forEach(input => input.dispatchEvent(new Event('change', {bubbles:true})));
        updatePresets();
    }));
    [from, to].forEach(input => input.addEventListener('change', updatePresets));
    updatePresets();
})();
