<?php
    $layoutBusinessName = 'Pharxmaco';
    $layoutBusinessType = 'Drugstore';
    $layoutFullName = $layoutBusinessName . ' ' . $layoutBusinessType;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/jpeg" href="<?= base_url('assets/images/pharxmaco-favicon.jpg') ?>?v=20260923">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($layoutFullName) ?></title>
    <!-- Apply browser-only interface preferences before the page is painted. -->
    <script>
    (function(){
        var defaults={theme:'system',accent:'blue',textSize:'normal',density:'comfortable',largeControls:false,reduceMotion:false,highContrast:false,stickyHeaders:false};
        var settings={};
        try{settings=Object.assign({},defaults,JSON.parse(localStorage.getItem('pharxmaco-ui-settings')||'{}'));}catch(e){settings=defaults;}
        if(!settings.theme){
            var legacy=localStorage.getItem('pharxmaco-theme');
            settings.theme=(legacy==='dark'||legacy==='light')?legacy:'system';
        }
        var dark=settings.theme==='dark'||(settings.theme==='system'&&window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches);
        var html=document.documentElement;
        html.classList.toggle('dark',dark);
        html.dataset.themePreference=settings.theme;
        html.dataset.accent=settings.accent||'blue';
        html.dataset.textSize=settings.textSize||'normal';
        html.dataset.density=settings.density||'comfortable';
        html.classList.toggle('large-controls',Boolean(settings.largeControls));
        html.classList.toggle('reduce-motion',Boolean(settings.reduceMotion));
        html.classList.toggle('high-contrast',Boolean(settings.highContrast));
        html.classList.toggle('sticky-table-headers',Boolean(settings.stickyHeaders));
    })();
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=DM+Mono:wght@400;500&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #eef3f6;
            --surface: #ffffff;
            --surface-2: #f7f9fc;
            --text: #132b3b;
            --text-2: #344c5e;
            --muted: #587084;
            --line: #dce5eb;
            --line-2: #bdceda;
            --heading-font: 'Manrope', 'DM Sans', system-ui, sans-serif;
            --surface-soft: var(--surface-2);
            --border: var(--line);
            --primary: #2166d1;
            --primary-dark: #1955b4;
            --on-primary: #ffffff;
            --primary-light: #e8f1ff;
            --primary-lighter: #f0f6ff;
            --primary-shadow: rgba(43,127,255,0.25);
            --ui-font-scale: 1;
            --danger: #e53e3e;
            --danger-bg: #fff5f5;
            --danger-text: #9b1c1c;
            --success: #16a34a;
            --success-bg: #f0fdf4;
            --success-text: #166534;
            --warning-bg: #fffbeb;
            --warning-text: #92400e;
            --sidebar-width: 248px;
            --topbar-h: 68px;
            --radius: 10px;
            --radius-lg: 16px;
            --shadow: 0 2px 6px rgba(13,27,46,0.035);
            --shadow-md: 0 4px 20px rgba(0,40,100,0.12);

            /* ── Sidebar palette ── */
            --sb-bg:       #0d1b2e;
            --sb-header:   #091525;
            --sb-border:   rgba(255,255,255,0.06);
            --sb-hover:    rgba(255,255,255,0.07);
            --sb-active:   rgba(59,130,246,0.18);
            --sb-active-text: #93c5fd;
            --sb-active-bar:  #3b82f6;
            --sb-label:    #97a9c1;
            --sb-icon-bg:  rgba(255,255,255,0.06);
            --sb-icon-active: rgba(59,130,246,0.28);

            /* ── Responsive form-grid columns (overridden at breakpoints below) ── */
            --grid-2col: 1fr 1fr;
            --grid-3col: repeat(3, 1fr);
            --grid-sidebar-280: 1fr 280px;
            --grid-sidebar-296-288: 1fr 296px 288px;
            --grid-sidebar-320: 1fr 320px;
            --grid-sidebar-340: 1fr 340px;
            --grid-sidebar-420: 420px 1fr;
        }

        /* ══════════════════════════════
           DARK MODE OVERRIDES
        ══════════════════════════════ */
        html.dark {
            --bg:              #0f1623;
            --surface:         #161e2e;
            --surface-2:       #1c2639;
            --text:            #e8edf5;
            --text-2:          #b0bdce;
            --muted:           #9aabc1;
            --line:            #243044;
            --line-2:          #2e3f58;
            --primary:         #4d9fff;
            --primary-dark:    #3b8fe8;
            --on-primary:      #0d1b2e;
            --primary-light:   rgba(77,159,255,0.12);
            --primary-lighter: rgba(77,159,255,0.07);
            --primary-shadow: rgba(77,159,255,0.28);
            --danger:          #f06060;
            --danger-bg:       rgba(240,96,96,0.12);
            --danger-text:     #ffb3b3;
            --success:         #34c26a;
            --success-bg:      rgba(52,194,106,0.12);
            --success-text:    #a7f3c4;
            --warning-bg:      rgba(245,158,11,0.12);
            --warning-text:    #fcd68a;
            --shadow:          0 2px 6px rgba(0,0,0,0.18);
            --shadow-md:       0 4px 20px rgba(0,0,0,0.5);

            /* Sidebar stays dark-navy — just slightly lighter for contrast */
            --sb-bg:           #111827;
            --sb-header:       #0d1420;
            --sb-border:       rgba(255,255,255,0.07);
            --sb-hover:        rgba(255,255,255,0.06);
        }

        /* Browser-only interface preferences. */
        html[data-accent="blue"] {
            --primary-shadow: rgba(43,127,255,.25);
            --sb-active: rgba(59,130,246,.18);
            --sb-active-text: #93c5fd;
            --sb-active-bar: #3b82f6;
            --sb-icon-active: rgba(59,130,246,.28);
        }
        html.dark[data-accent="blue"] { --primary-shadow: rgba(77,159,255,.28); }

        html[data-accent="green"] {
            --primary: #10774c;
            --primary-dark: #0b613d;
            --primary-light: #e5f7ef;
            --primary-lighter: #f0fbf6;
            --primary-shadow: rgba(21,155,98,.25);
            --sb-active: rgba(21,155,98,.20);
            --sb-active-text: #8ee6bd;
            --sb-active-bar: #22b979;
            --sb-icon-active: rgba(21,155,98,.30);
        }
        html.dark[data-accent="green"] {
            --primary: #36c985;
            --primary-dark: #24ae70;
            --primary-light: rgba(54,201,133,.14);
            --primary-lighter: rgba(54,201,133,.07);
            --primary-shadow: rgba(54,201,133,.28);
            --sb-active: rgba(54,201,133,.18);
            --sb-active-text: #9df2c9;
            --sb-active-bar: #36c985;
            --sb-icon-active: rgba(54,201,133,.25);
        }
        html[data-accent="purple"] {
            --primary: #7c5ce7;
            --primary-dark: #6545ce;
            --primary-light: #f0ebff;
            --primary-lighter: #f7f4ff;
            --primary-shadow: rgba(124,92,231,.25);
            --sb-active: rgba(124,92,231,.20);
            --sb-active-text: #c5b7ff;
            --sb-active-bar: #8d70ee;
            --sb-icon-active: rgba(124,92,231,.30);
        }
        html.dark[data-accent="purple"] {
            --primary: #a58aff;
            --primary-dark: #8b6fea;
            --primary-light: rgba(165,138,255,.14);
            --primary-lighter: rgba(165,138,255,.07);
            --primary-shadow: rgba(165,138,255,.28);
            --sb-active: rgba(165,138,255,.18);
            --sb-active-text: #d3c8ff;
            --sb-active-bar: #a58aff;
            --sb-icon-active: rgba(165,138,255,.25);
        }
        html[data-accent="orange"] {
            --primary: #ad5c00;
            --primary-dark: #914c00;
            --primary-light: #fff1df;
            --primary-lighter: #fff8ef;
            --primary-shadow: rgba(217,119,6,.25);
            --sb-active: rgba(217,119,6,.20);
            --sb-active-text: #ffd08c;
            --sb-active-bar: #e58b1c;
            --sb-icon-active: rgba(217,119,6,.30);
        }
        html.dark[data-accent="orange"] {
            --primary: #f3a53d;
            --primary-dark: #d98b24;
            --primary-light: rgba(243,165,61,.14);
            --primary-lighter: rgba(243,165,61,.07);
            --primary-shadow: rgba(243,165,61,.28);
            --sb-active: rgba(243,165,61,.18);
            --sb-active-text: #ffdaa2;
            --sb-active-bar: #f3a53d;
            --sb-icon-active: rgba(243,165,61,.25);
        }

        html[data-text-size="large"] { --ui-font-scale: 1.06; }
        html[data-text-size="extra-large"] { --ui-font-scale: 1.12; }
        html[data-text-size="large"] .content,
        html[data-text-size="large"] .topbar,
        html[data-text-size="large"] .sidebar { font-size: 1.055em; }
        html[data-text-size="extra-large"] .content,
        html[data-text-size="extra-large"] .topbar,
        html[data-text-size="extra-large"] .sidebar { font-size: 1.11em; }
        html[data-text-size="large"] .page-header h1 { font-size: 25px; }
        html[data-text-size="extra-large"] .page-header h1 { font-size: 27px; }
        html[data-text-size="large"] :is(.page-header p, .card-head p, .section-head p, table td, .btn, .label, .tag) { font-size: 15px; }
        html[data-text-size="extra-large"] :is(.page-header p, .card-head p, .section-head p, table td, .btn, .label, .tag) { font-size: 16px; }
        html[data-text-size="large"] table th { font-size: 13px; }
        html[data-text-size="extra-large"] table th { font-size: 14px; }
        html[data-text-size="large"] input,
        html[data-text-size="large"] select,
        html[data-text-size="large"] textarea,
        html[data-text-size="large"] button { font-size: 15px; }
        html[data-text-size="extra-large"] input,
        html[data-text-size="extra-large"] select,
        html[data-text-size="extra-large"] textarea,
        html[data-text-size="extra-large"] button { font-size: 16px; }

        html[data-density="compact"] .content { padding: 18px; }
        html[data-density="compact"] .card-head { padding: 13px 15px; }
        html[data-density="compact"] .card-body { padding: 13px 15px; }
        html[data-density="compact"] table th { padding: 8px 10px; }
        html[data-density="compact"] table td { padding: 9px 10px; }
        html[data-density="compact"] .field { margin-bottom: 11px; }
        html[data-density="spacious"] .content { padding: 30px; }
        html[data-density="spacious"] .card-head { padding: 22px 24px; }
        html[data-density="spacious"] .card-body { padding: 22px 24px; }
        html[data-density="spacious"] table th { padding: 14px 17px; }
        html[data-density="spacious"] table td { padding: 16px 17px; }
        html[data-density="spacious"] .field { margin-bottom: 20px; }

        html.large-controls .btn:not(.btn-sm),
        html.large-controls button:not(.btn-sm) { min-height: 44px; }
        html.large-controls input[type="text"],
        html.large-controls input[type="number"],
        html.large-controls input[type="password"],
        html.large-controls input[type="email"],
        html.large-controls input[type="tel"],
        html.large-controls input[type="search"],
        html.large-controls input[type="url"],
        html.large-controls input[type="date"],
        html.large-controls input[type="time"],
        html.large-controls input[type="datetime-local"],
        html.large-controls select,
        html.large-controls textarea,
        html.large-controls .input { min-height: 44px; }

        html.reduce-motion *,
        html.reduce-motion *::before,
        html.reduce-motion *::after {
            animation-duration: .01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: .01ms !important;
            scroll-behavior: auto !important;
        }

        html.high-contrast {
            --muted: #405773;
            --line: #a8bad0;
            --line-2: #748ca8;
            --shadow: none;
            --shadow-md: none;
        }
        html.dark.high-contrast {
            --text: #ffffff;
            --text-2: #e1e9f4;
            --muted: #b8c7db;
            --line: #667a96;
            --line-2: #8ca0bc;
        }
        html.high-contrast :focus-visible {
            outline: 3px solid var(--primary) !important;
            outline-offset: 2px !important;
        }
        html.high-contrast :is(.card, input, select, textarea, .input, .btn-secondary) {
            border-color: var(--line-2);
        }

        html.sticky-table-headers .table-wrap {
            max-height: min(68vh, 720px);
            overflow: auto;
            overscroll-behavior: contain;
        }
        html.sticky-table-headers .table-wrap table thead th {
            position: sticky;
            top: 0;
            z-index: 3;
            box-shadow: 0 1px 0 var(--line);
        }

        /* Dark mode table row hover */
        html.dark table tbody tr:hover { background: rgba(77,159,255,0.06); }

        /* Dark mode input backgrounds */
        html.dark input[type="text"],
        html.dark input[type="number"],
        html.dark input[type="password"],
        html.dark input[type="email"],
        html.dark input[type="date"],
        html.dark select,
        html.dark textarea,
        html.dark .input {
            background: var(--surface-2);
            color: var(--text);
            border-color: var(--line-2);
        }

        html.dark input::placeholder { color: var(--muted); }

        /* Dark mode scrollbar */
        html.dark { color-scheme: dark; }

        /* ── Dark mode toggle button ── */
        .theme-toggle {
            width: 34px; height: 34px;
            border: none;
            border-radius: 8px;
            background: transparent;
            cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            color: var(--muted);
            flex-shrink: 0;
            transition: background .15s, color .15s;
            position: relative;
        }
        .theme-toggle:hover { background: var(--primary-light); color: var(--primary); }

        .theme-toggle .icon-sun,
        .theme-toggle .icon-moon { position: absolute; transition: opacity .2s, transform .2s; }
        .theme-toggle .icon-sun  { opacity: 1; transform: scale(1); }
        .theme-toggle .icon-moon { opacity: 0; transform: scale(0.7); }

        html.dark .theme-toggle .icon-sun  { opacity: 0; transform: scale(0.7); }
        html.dark .theme-toggle .icon-moon { opacity: 1; transform: scale(1); }

        /* Dark mode topbar separator */
        html.dark .topbar-datetime { color: var(--muted); }
        html.dark .topbar-user:hover { background: var(--surface-2); }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        html, body {
            height: 100%;
            font-family: 'DM Sans', system-ui, sans-serif;
            font-size: 15px;
            background: var(--bg);
            color: var(--text);
            -webkit-font-smoothing: antialiased;
        }

        a { color: inherit; text-decoration: none; }
        .sr-only {
            position: absolute !important;
            width: 1px !important;
            height: 1px !important;
            padding: 0 !important;
            margin: -1px !important;
            overflow: hidden !important;
            clip: rect(0, 0, 0, 0) !important;
            white-space: nowrap !important;
            border: 0 !important;
        }

        .layout { display: flex; min-height: 100vh; }

        /* ══════════════════════════════
           SIDEBAR
        ══════════════════════════════ */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--sb-bg);
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0; left: 0; bottom: 0;
            z-index: 200;
            transform: translateX(-100%);
            transition: transform .22s cubic-bezier(.4,0,.2,1);
            overflow: hidden;
            /* right edge separation */
            box-shadow: 1px 0 0 var(--sb-border), 8px 0 40px rgba(0,8,24,0.55);
        }

        .sidebar.open { transform: translateX(0); }

        /* ── Brand / Logo strip ── */
        .brand {
            display: flex;
            align-items: center;
            gap: 11px;
            height: 64px;
            padding: 0 15px;
            background: var(--sb-header);
            flex-shrink: 0;
            overflow: hidden;
            white-space: nowrap;
            position: relative;
        }

        /* thin glowing separator line */
        .brand::after {
            content: '';
            position: absolute;
            bottom: 0; left: 0; right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent 0%, color-mix(in srgb, var(--primary) 50%, transparent) 40%, color-mix(in srgb, var(--primary) 72%, white) 60%, transparent 100%);
        }

        .brand-icon {
            width: 36px; height: 36px;
            border-radius: 10px;
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            flex-shrink: 0;
            overflow: hidden;
            box-shadow: 0 2px 10px var(--primary-shadow), inset 0 0 0 1px rgba(255,255,255,.15);
        }

        .brand-icon img { width: 100%; height: 100%; object-fit: cover; display: block; }

        .brand-text { min-width: 0; }

        .brand-name {
            font-size: 15px;
            font-weight: 800;
            color: #fff;
            letter-spacing: .1px;
            line-height: 1.2;
        }

        .brand-sub {
            font-size: 10px;
            font-weight: 600;
            color: #97a9c1;
            letter-spacing: .8px;
            text-transform: uppercase;
            margin-top: 2px;
        }

        /* ── Scrollable nav area ── */
        .nav-section {
            flex: 1;
            padding: 10px 10px 6px;
            overflow-y: auto;
            overflow-x: hidden;
            scrollbar-width: thin;
            scrollbar-color: rgba(255,255,255,.08) transparent;
        }

        .nav-section::-webkit-scrollbar { width: 2px; }
        .nav-section::-webkit-scrollbar-thumb { background: rgba(255,255,255,.1); border-radius: 2px; }

        /* ── Section label ── */
        .nav-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 9.5px;
            font-weight: 700;
            letter-spacing: 1.3px;
            text-transform: uppercase;
            color: var(--sb-label);
            padding: 14px 8px 6px;
            white-space: nowrap;
            overflow: hidden;
            transition: opacity .2s, max-height .2s, padding .2s;
        }

        /* decorative line after label text */
        .nav-label::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--sb-border);
            border-radius: 1px;
            min-width: 0;
        }

        /* ── Nav item ── */
        .nav-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 9px 10px;
            border-radius: 10px;
            color: #b7c5d8;
            font-size: 13.5px;
            font-weight: 500;
            cursor: pointer;
            position: relative;
            white-space: nowrap;
            overflow: hidden;
            margin-bottom: 2px;
            transition: background .14s, color .14s;
            letter-spacing: .05px;
        }

        .nav-item:hover {
            background: var(--sb-hover);
            color: rgba(255,255,255,.88);
        }

        .nav-item:hover .nav-icon {
            background: rgba(255,255,255,.1);
            color: rgba(255,255,255,.85);
        }

        /* Active state — pill with blue tint + left bar */
        .nav-item.active {
            background: var(--sb-active);
            color: var(--sb-active-text);
            font-weight: 600;
            border: 1px solid color-mix(in srgb, var(--primary) 28%, transparent);
        }

        .nav-item.active .nav-icon {
            background: var(--sb-icon-active);
            color: var(--sb-active-text);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            left: 0; top: 22%; bottom: 22%;
            width: 3px;
            background: linear-gradient(180deg, color-mix(in srgb, var(--sb-active-bar) 75%, white), var(--sb-active-bar));
            border-radius: 0 3px 3px 0;
        }

        /* ── Nav icon box ── */
        .nav-icon {
            width: 32px; height: 32px;
            border-radius: 8px;
            background: var(--sb-icon-bg);
            color: #a6b8cf;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            transition: background .14s, color .14s;
        }

        .nav-text {
            flex: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* ── Divider ── */
        .nav-divider {
            height: 1px;
            margin: 7px 6px;
            background: linear-gradient(90deg,
                transparent, rgba(255,255,255,.07), transparent);
        }

        /* ── Footer (logout) ── */
        .sidebar-footer {
            padding: 8px 10px 12px;
            flex-shrink: 0;
            background: rgba(0,0,0,.2);
            border-top: 1px solid var(--sb-border);
        }

        .sidebar-footer .settings-item {
            margin-bottom: 7px;
            background: rgba(255,255,255,.035);
            border: 1px solid rgba(255,255,255,.065);
        }

        .sidebar-footer .settings-item:hover {
            background: var(--sb-hover);
            border-color: rgba(255,255,255,.11);
        }

        .sidebar-footer .settings-item.active {
            background: var(--sb-active);
            border-color: rgba(59,130,246,.2);
        }

        .sidebar-footer .footer-divider {
            height: 1px;
            margin: 1px 6px 7px;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,.08), transparent);
        }

        .nav-item.logout-item {
            color: rgba(248,113,113,.55);
        }

        .nav-item.logout-item:hover {
            background: rgba(185,28,28,.14);
            color: rgba(252,165,165,.9);
        }

        .nav-item.logout-item .nav-icon {
            background: rgba(185,28,28,.12);
            color: rgba(248,113,113,.7);
        }

        /* ── MAIN ── */
        .main {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        /* ── TOPBAR ── */
        .topbar {
            height: var(--topbar-h);
            background: var(--surface);
            border-bottom: 1px solid var(--line);
            display: flex;
            align-items: center;
            gap: 0;
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 100;
            flex-shrink: 0;
        }

        /* Left accent strip */
        .topbar-left {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0 18px 0 20px;
            height: 100%;
            border-right: 1px solid var(--line);
        }

        .topbar-toggle {
            width: 34px; height: 34px;
            border: none;
            border-radius: 8px;
            background: transparent;
            cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            font-size: 15px;
            flex-shrink: 0;
            color: var(--muted);
            transition: background .15s, color .15s;
        }
        .topbar-toggle:hover { background: var(--primary-light); color: var(--primary); }

        /* Page breadcrumb area */
        .topbar-crumb {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 0 18px;
            flex: 1;
        }
        .topbar-crumb-icon {
            width: 30px; height: 30px;
            border-radius: 8px;
            background: var(--primary-light);
            color: var(--primary);
            display: flex; align-items: center; justify-content: center;
            font-size: 14px;
            flex-shrink: 0;
        }
        .topbar-crumb-text {
            display: flex;
            flex-direction: column;
        }
        .topbar-crumb-label {
            font-size: 9px;
            font-weight: 700;
            letter-spacing: 1.2px;
            text-transform: uppercase;
            color: var(--muted);
            line-height: 1;
        }
        .topbar-crumb-title {
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            letter-spacing: -.1px;
            line-height: 1.3;
        }

        /* Right side */
        .topbar-right {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 0;
            height: 100%;
        }

        /* Date/time pill */
        .topbar-datetime {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 0 16px;
            height: 100%;
            border-left: 1px solid var(--line);
            color: var(--muted);
            font-size: 12.5px;
            font-weight: 500;
            white-space: nowrap;
        }
        .topbar-datetime svg { opacity: .6; flex-shrink: 0; }

        /* Inventory notification menu */
        .notification-wrap {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
            padding: 0 8px;
            border-left: 1px solid var(--line);
        }
        .notification-btn {
            position: relative;
            width: 38px;
            height: 38px;
            border: 0;
            border-radius: 10px;
            background: transparent;
            color: var(--muted);
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: background .15s, color .15s, transform .15s;
        }
        .notification-btn:hover,
        .notification-btn[aria-expanded="true"] {
            background: var(--primary-light);
            color: var(--primary);
        }
        .notification-btn:active { transform: scale(.96); }
        .notification-badge {
            position: absolute;
            top: 2px;
            right: 1px;
            min-width: 17px;
            height: 17px;
            padding: 0 4px;
            border-radius: 999px;
            border: 2px solid var(--surface);
            background: var(--danger);
            color: #fff;
            font-size: 9px;
            line-height: 13px;
            font-weight: 800;
            text-align: center;
        }
        .notification-menu {
            display: none;
            position: absolute;
            top: calc(100% - 6px);
            right: 8px;
            width: min(380px, calc(100vw - 24px));
            overflow: hidden;
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 14px;
            box-shadow: var(--shadow-md);
            z-index: 250;
        }
        .notification-menu.open { display: block; }
        .notification-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 15px 16px 12px;
            border-bottom: 1px solid var(--line);
        }
        .notification-head strong { display: block; font-size: 14px; color: var(--text); }
        .notification-head span { display: block; margin-top: 2px; font-size: 11.5px; color: var(--muted); }
        .notification-total {
            flex-shrink: 0;
            padding: 4px 9px;
            border-radius: 999px;
            background: var(--danger-bg);
            color: var(--danger-text);
            font-size: 11px;
            font-weight: 800;
        }
        .notification-list { max-height: 360px; overflow-y: auto; }
        .notification-item {
            display: grid;
            grid-template-columns: 34px 1fr 16px;
            align-items: start;
            gap: 10px;
            padding: 13px 16px;
            color: inherit;
            text-decoration: none;
            border-bottom: 1px solid var(--line);
            transition: background .15s;
        }
        .notification-item:last-child { border-bottom: 0; }
        .notification-item:hover { background: var(--surface-2); }
        .notification-icon {
            width: 34px;
            height: 34px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .notification-icon.danger { background: var(--danger-bg); color: var(--danger); }
        .notification-icon.warning { background: var(--warning-bg); color: #d97706; }
        .notification-icon.info { background: var(--primary-light); color: var(--primary); }
        .notification-copy strong { display: block; font-size: 13px; color: var(--text); }
        .notification-copy span { display: block; margin-top: 3px; font-size: 11.5px; line-height: 1.45; color: var(--muted); }
        .notification-arrow { color: var(--muted); margin-top: 9px; }
        .notification-empty {
            padding: 28px 18px;
            text-align: center;
            color: var(--muted);
            font-size: 13px;
        }
        .notification-empty svg { display: block; margin: 0 auto 9px; color: var(--success); }
        button.notification-item {
            width: 100%;
            border: 0;
            border-bottom: 1px solid var(--line);
            background: transparent;
            text-align: left;
            font: inherit;
            cursor: pointer;
        }
        button.notification-item:last-child { border-bottom: 0; }

        /* Low-stock product popup */
        body.inventory-modal-open { overflow: hidden; }
        .inventory-modal {
            display: none;
            position: fixed;
            inset: 0;
            z-index: 600;
            padding: 24px;
            background: rgba(8, 18, 34, .58);
            align-items: center;
            justify-content: center;
        }
        .inventory-modal.open { display: flex; }
        .inventory-modal-dialog {
            width: min(820px, 100%);
            max-height: min(760px, calc(100vh - 48px));
            display: flex;
            flex-direction: column;
            overflow: hidden;
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 16px;
            box-shadow: 0 24px 70px rgba(0, 18, 48, .28);
        }
        .inventory-modal-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
            padding: 18px 20px 15px;
            border-bottom: 1px solid var(--line);
        }
        .inventory-modal-title-wrap { min-width: 0; }
        .inventory-modal-title {
            display: flex;
            align-items: center;
            gap: 9px;
            color: var(--text);
            font-size: 18px;
            font-weight: 800;
        }
        .inventory-modal-title-icon {
            width: 34px;
            height: 34px;
            flex-shrink: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            background: var(--warning-bg);
            color: #d97706;
        }
        .inventory-modal-subtitle {
            margin-top: 5px;
            color: var(--muted);
            font-size: 12.5px;
            line-height: 1.45;
        }
        .inventory-modal-close {
            width: 38px;
            height: 38px;
            flex-shrink: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--line);
            border-radius: 10px;
            background: var(--surface-2);
            color: var(--muted);
            cursor: pointer;
            transition: background .15s, color .15s, border-color .15s;
        }
        .inventory-modal-close:hover {
            border-color: var(--line-2);
            background: var(--danger-bg);
            color: var(--danger);
        }
        .inventory-modal-tools {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 13px 20px;
            border-bottom: 1px solid var(--line);
            background: var(--surface-2);
        }
        .inventory-modal-count {
            color: var(--text-2);
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }
        .inventory-search-wrap {
            position: relative;
            width: min(340px, 100%);
        }
        .inventory-search-wrap svg {
            position: absolute;
            left: 11px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--muted);
            pointer-events: none;
        }
        .inventory-search {
            width: 100%;
            height: 39px;
            padding: 0 12px 0 35px;
            border: 1px solid var(--line-2);
            border-radius: 10px;
            background: var(--surface);
            color: var(--text);
            font: inherit;
            font-size: 13px;
            outline: none;
        }
        .inventory-search:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px var(--primary-light);
        }
        .low-stock-list {
            min-height: 0;
            overflow-y: auto;
            padding: 0 20px 6px;
        }
        .low-stock-row {
            display: grid;
            grid-template-columns: minmax(185px, 1.55fr) minmax(115px, 1fr) 74px 92px 118px 92px;
            gap: 12px;
            align-items: center;
            min-width: 820px;
            padding: 12px 2px;
            border-bottom: 1px solid var(--line);
        }
        .low-stock-row-head {
            position: sticky;
            top: 0;
            z-index: 1;
            padding-top: 11px;
            padding-bottom: 9px;
            background: var(--surface);
            color: var(--muted);
            font-size: 10.5px;
            font-weight: 800;
            letter-spacing: .45px;
            text-transform: uppercase;
        }
        .low-stock-row:last-of-type { border-bottom: 0; }
        .low-stock-product strong {
            display: block;
            color: var(--text);
            font-size: 13px;
            line-height: 1.35;
        }
        .low-stock-product small {
            display: block;
            margin-top: 3px;
            color: var(--muted);
            font-family: 'DM Mono', monospace;
            font-size: 10.5px;
        }
        .low-stock-cell {
            min-width: 0;
            color: var(--text-2);
            font-size: 12.5px;
        }
        .low-stock-number { font-family: 'DM Mono', monospace; font-weight: 700; }
        .low-stock-forecast {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 78px;
            padding: 5px 8px;
            border-radius: 8px;
            background: var(--primary-light);
            color: var(--primary);
            font-family: 'DM Mono', monospace;
            font-size: 11.5px;
            font-weight: 800;
            white-space: nowrap;
        }
        .low-stock-forecast.no-demand {
            border: 1px solid var(--line);
            background: var(--surface-2);
            color: var(--muted);
            font-family: 'DM Sans', system-ui, sans-serif;
            font-size: 10.5px;
        }
        .low-stock-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 64px;
            padding: 5px 8px;
            border-radius: 999px;
            background: var(--warning-bg);
            color: var(--warning-text);
            font-size: 10.5px;
            font-weight: 800;
            white-space: nowrap;
        }
        .low-stock-badge.out { background: var(--danger-bg); color: var(--danger-text); }
        .low-stock-empty-search {
            display: none;
            padding: 36px 20px;
            text-align: center;
            color: var(--muted);
            font-size: 13px;
        }
        .inventory-modal-note {
            padding: 10px 20px;
            border-top: 1px solid var(--line);
            background: var(--warning-bg);
            color: var(--warning-text);
            font-size: 11.5px;
            line-height: 1.45;
        }
        .inventory-modal-footer {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 10px;
            padding: 14px 20px;
            border-top: 1px solid var(--line);
        }
        .inventory-modal-link,
        .inventory-modal-done {
            min-height: 39px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            padding: 0 14px;
            border-radius: 10px;
            font-size: 12.5px;
            font-weight: 700;
            cursor: pointer;
        }
        .inventory-modal-link {
            border: 1px solid var(--primary);
            background: var(--primary);
            color: #fff;
        }
        .inventory-modal-link:hover { background: var(--primary-dark); }
        .inventory-modal-done {
            border: 1px solid var(--line-2);
            background: var(--surface);
            color: var(--text-2);
        }
        .inventory-modal-done:hover { background: var(--surface-2); }

        @media (max-width: 700px) {
            .inventory-modal { padding: 0; align-items: stretch; }
            .inventory-modal-dialog {
                width: 100%;
                max-height: 100vh;
                min-height: 100vh;
                border: 0;
                border-radius: 0;
            }
            .inventory-modal-header { padding: 15px 15px 12px; }
            .inventory-modal-title { font-size: 16px; }
            .inventory-modal-tools {
                align-items: stretch;
                flex-direction: column;
                padding: 11px 15px;
            }
            .inventory-search-wrap { width: 100%; }
            .low-stock-list { padding: 8px 15px; }
            .low-stock-row-head { display: none; }
            .low-stock-row {
                min-width: 0;
                grid-template-columns: 1fr 1fr;
                gap: 9px 14px;
                margin-bottom: 10px;
                padding: 13px;
                border: 1px solid var(--line);
                border-radius: 12px;
                background: var(--surface-2);
            }
            .low-stock-product { grid-column: 1 / -1; padding-bottom: 4px; }
            .low-stock-cell::before {
                content: attr(data-label);
                display: block;
                margin-bottom: 3px;
                color: var(--muted);
                font-size: 9.5px;
                font-weight: 800;
                letter-spacing: .35px;
                text-transform: uppercase;
            }
            .inventory-modal-note { padding: 9px 15px; }
            .inventory-modal-footer { padding: 12px 15px; }
            .inventory-modal-link,
            .inventory-modal-done { min-height: 44px; }
        }

        @media (max-width: 420px) {
            .inventory-modal-footer { flex-direction: column-reverse; align-items: stretch; }
            .inventory-modal-link,
            .inventory-modal-done { width: 100%; }
        }

        /* User section */
        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0 20px;
            height: 100%;
            border-left: 1px solid var(--line);
            cursor: default;
            transition: background .15s;
        }
        .topbar-user:hover { background: var(--surface-2); }

        .user-avatar {
            width: 34px; height: 34px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--primary) 0%, #1a6fe8 100%);
            color: #fff;
            font-size: 12px;
            font-weight: 800;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
            letter-spacing: .5px;
        }

        .user-info .user-name { font-size: 13.5px; font-weight: 700; line-height: 1.2; color: var(--text); }
        .user-info .user-role {
            font-size: 11px;
            color: var(--muted);
            font-weight: 500;
        }

        /* Role badge dot */
        .role-dot {
            width: 6px; height: 6px;
            border-radius: 50%;
            background: var(--success);
            flex-shrink: 0;
            box-shadow: 0 0 0 2px rgba(22,163,74,.18);
        }

        /* ── PAGE CONTENT ── */
        .content { flex: 1; padding: 24px; }

        /* ── COMPONENTS ── */
        .page-header { margin-bottom: 22px; }
        .page-header h1 { font-size: 24px; font-weight: 800; letter-spacing: -.4px; color: var(--text); }
        .page-header p { font-size: 14px; color: var(--muted); margin-top: 4px; }

        .card { background: var(--surface); border: 1.5px solid var(--line); border-radius: var(--radius-lg); box-shadow: var(--shadow); }

        .card-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; padding: 18px 20px; border-bottom: 1.5px solid var(--line); }
        .card-head h2 { font-size: 16px; font-weight: 700; }
        .card-head p { font-size: 13px; color: var(--muted); margin-top: 2px; }
        .card-body { padding: 18px 20px; }

        /* Tables */
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        table th { background: var(--surface-2); font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; color: var(--muted); padding: 11px 14px; text-align: left; white-space: nowrap; border-bottom: 1.5px solid var(--line); }
        table td { padding: 13px 14px; border-bottom: 1px solid var(--line); font-size: 14px; color: var(--text-2); vertical-align: middle; }
        table tbody tr:last-child td { border-bottom: none; }
        table tbody tr:hover { background: var(--primary-lighter); }

        /* Buttons */
        .btn { display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 9px 16px; border: none; border-radius: var(--radius); font-size: 14px; font-weight: 600; font-family: inherit; cursor: pointer; transition: all .15s; line-height: 1; min-height: 38px; white-space: nowrap; }
        .btn:hover { opacity: .88; }
        .btn:active { transform: scale(.98); }
        .btn-primary { background: var(--primary); color: #fff; box-shadow: 0 2px 8px var(--primary-shadow); }
        .btn-primary:hover { background: var(--primary-dark); opacity: 1; }
        .btn-secondary { background: var(--surface-2); color: var(--text-2); border: 1.5px solid var(--line-2); }
        .btn-danger { background: var(--danger); color: #fff; }
        .btn-sm { padding: 6px 11px; font-size: 13px; min-height: 32px; }
        .btn-lg { padding: 12px 22px; font-size: 16px; min-height: 46px; }
        .btn-full { width: 100%; }
        .btn.secondary { background: var(--surface-2); color: var(--text-2); border: 1.5px solid var(--line-2); }
        .btn.danger { background: var(--danger); color: #fff; }
        .btn-success { background: var(--success); color: #fff; }
        .btn-warning { background: #d97706; color: #fff; }
        .btn[disabled], button[disabled] { opacity: .62; cursor: not-allowed; transform: none !important; }
        .inline-action-form { display: inline-flex; margin: 0; }
        .action-group { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .form-help, .hint { display: block; margin-top: 5px; color: var(--muted); font-size: 12px; line-height: 1.45; }
        .required-mark, .text-danger { color: var(--danger); }
        .field-error { margin-top: 5px; color: var(--danger-text); font-size: 12px; font-weight: 600; }
        .input.is-invalid { border-color: var(--danger); box-shadow: 0 0 0 3px rgba(229,62,62,.1); }
        .empty-state { text-align: center; padding: 34px 18px !important; color: var(--muted); }
        .form-grid-2 { display: grid; grid-template-columns: var(--grid-2col); gap: 14px; }
        .filter-actions { display: flex; gap: 8px; align-items: flex-end; flex-wrap: wrap; }

        /* Badges */
        .badge { display: inline-flex; align-items: center; padding: 3px 9px; border-radius: 999px; font-size: 11.5px; font-weight: 700; }
        .badge-success { background: var(--success-bg); color: var(--success-text); }
        .badge-danger { background: var(--danger-bg); color: var(--danger-text); }
        .badge-warning { background: var(--warning-bg); color: var(--warning-text); }
        .badge-neutral { background: var(--surface-2); color: var(--muted); border: 1px solid var(--line); }
        .badge.danger { background: var(--danger); color: #fff; }
        .badge.warning { background: #f59e0b; color: #fff; }

        /* Alerts */
        .alert { padding: 13px 16px; border-radius: var(--radius); font-size: 14px; margin-bottom: 16px; border: 1.5px solid transparent; font-weight: 500; }
        .alert.success { background: var(--success-bg); color: var(--success-text); border-color: #bbf7d0; }
        .alert.error, .alert.danger { background: var(--danger-bg); color: var(--danger-text); border-color: #fecaca; }
        .alert.warning { background: var(--warning-bg); color: var(--warning-text); border-color: #fde68a; }

        /* Forms */
        .field { margin-bottom: 16px; }
        .field:last-child { margin-bottom: 0; }
        label, .label { display: block; font-size: 13px; font-weight: 600; color: var(--text-2); margin-bottom: 5px; }
        input[type="text"], input[type="number"], input[type="password"], input[type="email"], select, textarea, .input { width: 100%; padding: 9px 12px; border: 1.5px solid var(--line-2); border-radius: var(--radius); font-size: 14px; font-family: inherit; color: var(--text); background: var(--surface); transition: border-color .15s, box-shadow .15s; outline: none; }
        input:focus, select:focus, textarea:focus, .input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(43,127,255,.12); }
        input:disabled, select:disabled { background: var(--surface-2); color: var(--muted); cursor: not-allowed; }

        /* Pagination (CI4 default pager: <nav><ul class="pagination"><li><a>) */
        .paginationWrap { margin-top: 20px; display: flex; justify-content: center; }
        .pagination {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
            justify-content: center;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .pagination li { display: flex; }
        .pagination li a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 34px;
            height: 34px;
            padding: 0 10px;
            border-radius: var(--radius);
            border: 1.5px solid var(--line-2);
            background: var(--surface);
            color: var(--text-2);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all .15s;
        }
        /* First/Previous/Next/Last: hide the text label (kept for screen readers only)
           and show a compact chevron icon instead, so these render as plain single-box
           circular buttons matching the page-number buttons exactly. */
        .pagination li a[aria-label] {
            width: 34px;
            min-width: 34px;
            padding: 0;
            font-size: 0;
        }
        .pagination li a[aria-label] span {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0,0,0,0);
            white-space: nowrap;
            border: 0;
        }
        .pagination li a[aria-label]::before {
            font-size: 15px;
            font-weight: 700;
            line-height: 1;
        }
        .pagination li a[aria-label="First"]::before   { content: "\00ab"; }
        .pagination li a[aria-label="Previous"]::before { content: "\2039"; }
        .pagination li a[aria-label="Next"]::before     { content: "\203a"; }
        .pagination li a[aria-label="Last"]::before    { content: "\00bb"; }
        .pagination li a:hover { background: var(--primary-light); border-color: var(--primary); color: var(--primary); }
        .pagination li.active a {
            background: var(--primary);
            border-color: var(--primary);
            color: #fff;
            box-shadow: 0 2px 8px rgba(43,127,255,0.25);
        }

        /* Utility */
        .row { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        .muted { color: var(--muted); }
        .text-danger { color: var(--danger); font-weight: 600; }
        .text-warning { color: #d97706; font-weight: 600; }
        .text-success { color: var(--success); font-weight: 600; }

        .cards-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; margin-bottom: 22px; }

        .stat-card { background: var(--surface); border: 1.5px solid var(--line); border-radius: var(--radius-lg); box-shadow: var(--shadow); padding: 18px 20px; }
        .stat-label { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; color: var(--muted); margin-bottom: 8px; }
        .stat-value { font-size: 28px; font-weight: 800; color: var(--text); letter-spacing: -.5px; line-height: 1; }
        .stat-sub { font-size: 12.5px; color: var(--muted); margin-top: 5px; }
        .stat-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 12px; }

        .section-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 14px; flex-wrap: wrap; }
        .section-head h2 { font-size: 16px; font-weight: 700; }
        .section-head p { font-size: 13px; color: var(--muted); }

        .tag { display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 6px; font-size: 12.5px; font-weight: 600; background: var(--primary-light); color: var(--primary); }
        .stack { display: flex; flex-direction: column; gap: 16px; }

        .overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 190; backdrop-filter: blur(2px); }
        .overlay.show { display: block; }

        /* ── RESPONSIVE ── */
        @media (max-width: 900px) {
            /* Collapse fixed sidebar-style form layouts to a single column */
            :root {
                --grid-sidebar-280: 1fr;
                --grid-sidebar-296-288: 1fr;
                --grid-sidebar-320: 1fr;
                --grid-sidebar-340: 1fr;
                --grid-sidebar-420: 1fr;
            }

            /* Topbar: datetime is the least essential piece, drop it first */
            .topbar-datetime { display: none; }
        }

        @media (max-width: 600px) {
            .content { padding: 14px; }
            html[data-density="compact"] .content { padding: 10px; }
            html[data-density="spacious"] .content { padding: 18px; }
            html[data-density="spacious"] .card-head,
            html[data-density="spacious"] .card-body { padding: 17px; }
            html[data-density="spacious"] table th,
            html[data-density="spacious"] table td { padding: 12px 13px; }
            .stat-value { font-size: 24px; }

            /* Collapse equal-width field grids (e.g. First/Last name pairs) to one column */
            :root {
                --grid-2col: 1fr;
                --grid-3col: 1fr;
            }

            /* Topbar: trim to hamburger + page title + avatar so it fits a phone width */
            .topbar-left { padding: 0 12px; }
            .topbar-crumb { padding: 0 10px; gap: 8px; }
            .topbar-crumb-label { display: none; }
            .topbar-crumb-icon { width: 26px; height: 26px; }
            .topbar-datetime { display: none; }
            .topbar-user { padding: 0 10px; }
            .user-info { display: none; }
            .notification-wrap { padding: 0 4px; }
            .notification-btn { width: 36px; height: 36px; }
            .notification-menu {
                position: fixed;
                top: calc(var(--topbar-h) + 8px);
                right: 12px;
                left: 12px;
                width: auto;
            }

            /* Cards & tables: tighten padding/type-scale for small screens */
            .card-head, .card-body { padding: 14px 16px; }
            .page-header h1 { font-size: 20px; }
            table th, table td { padding: 10px 12px; font-size: 13px; }

            /* Prevent iOS Safari from auto-zooming when a field is focused */
            input[type="text"], input[type="number"], input[type="password"],
            input[type="email"], input[type="date"], select, textarea, .input {
                font-size: 16px;
            }
        }


        /* Global connection notice. This does not provide offline mode; it
           prevents users from assuming that server actions were received. */
        .global-connection-banner {
            position: fixed;
            top: 10px;
            left: 50%;
            z-index: 1200;
            transform: translate(-50%, -18px);
            display: flex;
            align-items: center;
            gap: 9px;
            max-width: min(620px, calc(100vw - 24px));
            padding: 10px 14px;
            border: 1px solid #ef9a9a;
            border-radius: 10px;
            background: #fff1f1;
            color: #8f1d1d;
            box-shadow: 0 8px 30px rgba(80, 15, 15, .18);
            font-size: 13px;
            font-weight: 700;
            line-height: 1.35;
            opacity: 0;
            pointer-events: none;
            transition: opacity .18s ease, transform .18s ease;
        }
        .global-connection-banner.show {
            opacity: 1;
            transform: translate(-50%, 0);
        }
        .global-connection-banner.restored {
            border-color: #86d5a5;
            background: #edfff4;
            color: #126332;
        }
        .global-connection-dot {
            width: 9px;
            height: 9px;
            flex: 0 0 auto;
            border-radius: 50%;
            background: currentColor;
            box-shadow: 0 0 0 4px color-mix(in srgb, currentColor 16%, transparent);
        }
        html.dark .global-connection-banner {
            border-color: rgba(239,154,154,.5);
            background: #311b22;
            color: #ffc0c0;
        }
        html.dark .global-connection-banner.restored {
            border-color: rgba(134,213,165,.45);
            background: #153326;
            color: #adf1c6;
        }
        @media (max-width: 620px) {
            .global-connection-banner {
                top: 8px;
                width: calc(100vw - 16px);
                max-width: none;
                justify-content: center;
                text-align: center;
            }
        }


        /* Automatic list/report filters. JavaScript adds these classes only
           after it has attached the auto-submit behavior, so the normal
           Filter/Search buttons remain a reliable no-JavaScript fallback. */
        form.auto-filter-enabled {
            position: relative;
        }
        .auto-filter-status {
            display: none;
            align-items: center;
            gap: 7px;
            flex: 1 0 100%;
            width: 100%;
            margin-top: 4px;
            color: var(--muted);
            font-size: 12px;
            font-weight: 600;
            line-height: 1.35;
        }
        .auto-filter-status.show {
            display: inline-flex;
        }
        .auto-filter-status::before {
            content: '';
            width: 11px;
            height: 11px;
            flex: 0 0 auto;
            border: 2px solid var(--line-2);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: auto-filter-spin .7s linear infinite;
        }
        .auto-filter-status.invalid {
            color: var(--danger-text);
        }
        .auto-filter-status.invalid::before,
        .auto-filter-status.offline::before {
            animation: none;
            border: 0;
            width: auto;
            height: auto;
            content: '⚠';
        }
        .auto-filter-status.offline {
            color: var(--warning-text);
        }
        form.auto-filter-submitting :is(input, select, textarea, button[type="submit"]) {
            cursor: wait;
        }
        form.auto-filter-submitting button[type="submit"] {
            opacity: .72;
        }
        form.auto-filter-enabled :is(input, select, textarea).auto-filter-invalid {
            border-color: var(--danger) !important;
            box-shadow: 0 0 0 3px color-mix(in srgb, var(--danger) 13%, transparent) !important;
        }
        @keyframes auto-filter-spin { to { transform: rotate(360deg); } }
        html.reduce-motion .auto-filter-status::before { animation: none; }

    </style>
    <link rel="stylesheet" href="<?= base_url('assets/css/workspace.css') ?>?v=20260916-2">
    <link rel="stylesheet" href="<?= base_url('assets/css/editors.css') ?>?v=20260916">
    <link rel="stylesheet" href="<?= base_url('assets/css/sidebar.css') ?>?v=20260922">
    <link rel="stylesheet" href="<?= base_url('assets/css/topbar.css') ?>?v=20260922">
    <link rel="stylesheet" href="<?= base_url('assets/css/modals.css') ?>?v=20260922">
    <script src="<?= base_url('assets/js/modals.js') ?>?v=20260922" defer></script>
    <script src="<?= base_url('assets/js/topbar.js') ?>?v=20260922" defer></script>
    <script src="<?= base_url('assets/js/workspace.js') ?>?v=20260916" defer></script>
</head>
<body>
<?php
    $role = session('role');
    $fullName = session('full_name');
    $branchName = session('branch_name');
    $displayRole = 'User';
    if ($role === 'admin') $displayRole = 'Administrator';
    elseif ($role === 'cashier') {
        $displayRole = !empty($branchName) ? str_replace(' Branch', '', $branchName) . ' Cashier' : 'Cashier';
    }
    $initials = implode('', array_map(fn($w) => strtoupper($w[0]), array_slice(explode(' ', trim($fullName ?: 'U')), 0, 2)));

    $notificationData = [
        'total' => 0,
        'badge' => '',
        'items' => [],
        'scope_label' => $role === 'cashier' ? 'Your branch' : 'All branches',
        'low_stock_total' => 0,
        'low_stock_products' => [],
        'low_stock_url' => '',
    ];
    try {
        $notificationData = (new \App\Libraries\TopbarNotificationService())->getSummary(
            (string) $role,
            session('branch_id') ? (int) session('branch_id') : null
        );
    } catch (\Throwable $e) {
        log_message('error', 'Topbar notifications could not be loaded: {message}', ['message' => $e->getMessage()]);
    }

    // Detect current URI for active nav highlighting
    $currentUri = '/' . ltrim(uri_string(), '/');
?>


<div class="global-connection-banner" id="globalConnectionBanner" role="status" aria-live="assertive">
    <span class="global-connection-dot" aria-hidden="true"></span>
    <span id="globalConnectionText">No internet connection. Unsaved actions have not been sent to the server.</span>
</div>

<a class="skip-link" href="#pageContent">Skip to content</a>
<div class="overlay" id="overlay" aria-hidden="true"></div>

<div class="layout">
    <?= view('layouts/sidebar', compact('role', 'fullName', 'branchName', 'displayRole', 'initials', 'currentUri', 'layoutBusinessName', 'layoutBusinessType')) ?>

    <div class="main" id="mainContent">
        <?= view('layouts/topbar', compact('role', 'fullName', 'branchName', 'displayRole', 'initials', 'layoutFullName', 'layoutBusinessName', 'notificationData')) ?>

        <main class="content" id="pageContent" tabindex="-1">
            <?= $this->renderSection('content') ?>
        </main>
    </div>
</div>

<?= view('layouts/low_stock_modal', ['notificationData' => $notificationData]) ?>

<script>
(function(){

    /* ── Connection awareness ── */
    const globalConnectionBanner = document.getElementById('globalConnectionBanner');
    const globalConnectionText = document.getElementById('globalConnectionText');
    let connectionRestoreTimer = null;

    function updateGlobalConnectionState(showRestored = false) {
        if (!globalConnectionBanner || !globalConnectionText) return;
        window.clearTimeout(connectionRestoreTimer);

        if (!navigator.onLine) {
            globalConnectionBanner.classList.remove('restored');
            globalConnectionBanner.classList.add('show');
            globalConnectionText.textContent = 'No internet connection. Unsaved actions have not been sent to the server.';
            return;
        }

        if (showRestored) {
            globalConnectionBanner.classList.add('restored', 'show');
            globalConnectionText.textContent = 'Connection restored. You may continue.';
            connectionRestoreTimer = window.setTimeout(function () {
                globalConnectionBanner.classList.remove('show', 'restored');
            }, 2800);
        } else {
            globalConnectionBanner.classList.remove('show', 'restored');
        }
    }

    window.addEventListener('offline', function () { updateGlobalConnectionState(false); });
    window.addEventListener('online', function () { updateGlobalConnectionState(true); });
    updateGlobalConnectionState(false);

    /* ── Live clock ── */
    function updateClock(){
        const now = new Date();
        const d = now.toLocaleDateString('en-PH', { month:'short', day:'numeric', year:'numeric', timeZone:'Asia/Manila' });
        const t = now.toLocaleTimeString('en-PH', { hour:'2-digit', minute:'2-digit', timeZone:'Asia/Manila' });
        const el = document.getElementById('clockDisplay');
        if (el) { el.textContent = t; el.setAttribute('datetime', now.toISOString()); }
        const dateEl = document.getElementById('clockDate');
        if (dateEl) dateEl.textContent = d;
    }
    updateClock();
    setInterval(updateClock, 30000);

    /* ── Topbar title sync from active nav ── */
    (function(){
        const active = document.querySelector('.nav-item.active .nav-text');
        const titleEl = document.getElementById('topbarTitle');
        if (active && titleEl) titleEl.textContent = active.textContent.trim();
        if (active) active.closest('a').setAttribute('aria-current', 'page');
        const heading = document.querySelector('#pageContent h1');
        if (heading) {
            const pageTitle = heading.textContent.trim();
            document.title = pageTitle + ' | ' + document.title;
            if (titleEl) titleEl.textContent = pageTitle;
        }
        if (titleEl) titleEl.title = titleEl.textContent;

        const activeIcon = document.querySelector('.nav-item.active .nav-icon');
        const iconBox = document.getElementById('topbarIcon');
        if (activeIcon && iconBox) iconBox.innerHTML = activeIcon.innerHTML;
    })();

    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const toggle  = document.getElementById('sidebarToggle');
    const sidebarClose = document.getElementById('sidebarClose');
    const mainContent = document.getElementById('mainContent');
    const sidebarSearch = document.getElementById('sidebarSearch');
    const sidebarSearchClear = document.getElementById('sidebarSearchClear');
    const navigationGroups = Array.from(sidebar.querySelectorAll('[data-nav-group]'));
    let sidebarPreviousOverflow = '';

    function filterSidebar() {
        const query = sidebarSearch.value.trim().toLocaleLowerCase();
        let count = 0;
        navigationGroups.forEach(function(group) {
            const groupMatches = group.querySelector('.nav-label').textContent.toLocaleLowerCase().includes(query);
            let visible = 0;
            group.querySelectorAll('[data-nav-link]').forEach(function(link) {
                link.hidden = !(groupMatches || link.textContent.toLocaleLowerCase().includes(query));
                if (!link.hidden) visible++;
            });
            group.hidden = visible === 0;
            count += visible;
        });
        sidebarSearchClear.hidden = !query;
        document.getElementById('sidebarEmpty').hidden = count !== 0;
        document.getElementById('sidebarSearchStatus').textContent = query ? count + (count === 1 ? ' matching page' : ' matching pages') : '';
    }
    sidebarSearch.addEventListener('input', filterSidebar);
    sidebarSearchClear.addEventListener('click', function() {
        sidebarSearch.value = '';
        filterSidebar();
        sidebarSearch.focus();
    });

    // Hidden by default at every screen width (see .sidebar's base CSS) —
    // the toggle button is the only way in, no hover-to-peek, no
    // breakpoint-dependent branching. That's what makes this immune to
    // the resize/breakpoint bugs the old mini+hover+mobile system had.
    function openSidebar() {
        if (sidebar.classList.contains('open')) return;
        closeNotifications();
        sidebarPreviousOverflow = document.body.style.overflow;
        sidebar.inert = false;
        sidebar.classList.add('open');
        overlay.classList.add('show');
        toggle.setAttribute('aria-expanded', 'true');
        sidebarClose.focus();
        mainContent.inert = true;
        document.body.style.overflow = 'hidden';
        requestAnimationFrame(function() {
            const activeLink = sidebar.querySelector('[aria-current="page"]');
            if (activeLink) activeLink.scrollIntoView({block: 'nearest'});
        });
    }
    function closeSidebar() {
        if (!sidebar.classList.contains('open')) return;
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
        mainContent.inert = false;
        toggle.setAttribute('aria-expanded', 'false');
        toggle.focus();
        sidebar.inert = true;
        document.body.style.overflow = sidebarPreviousOverflow;
        sidebarSearch.value = '';
        filterSidebar();
    }

    sidebarClose.addEventListener('click', closeSidebar);
    sidebar.addEventListener('keydown', function (event) {
        if (event.key !== 'Tab') return;
        const links = Array.from(sidebar.querySelectorAll('a[href], button:not([disabled]), input:not([disabled])'))
            .filter(function(element) { return element.getClientRects().length > 0; });
        const first = links[0];
        const last = links[links.length - 1];
        if (event.shiftKey && document.activeElement === first) {
            event.preventDefault(); last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault(); first.focus();
        }
    });

    toggle.addEventListener('click', function () {
        if (sidebar.classList.contains('open')) {
            closeSidebar();
        } else {
            openSidebar();
        }
    });

    overlay.addEventListener('click', closeSidebar);

    /* ── Low-stock product popup ── */
    const lowStockModal = document.getElementById('lowStockModal');
    const lowStockSearch = document.getElementById('lowStockSearch');
    const lowStockRows = Array.from(document.querySelectorAll('[data-low-stock-row]'));
    const lowStockVisibleCount = document.getElementById('lowStockVisibleCount');
    const lowStockEmptySearch = document.getElementById('lowStockEmptySearch');

    function filterLowStockRows(){
        if (!lowStockSearch) return;
        const query = lowStockSearch.value.trim().toLowerCase();
        let visible = 0;

        lowStockRows.forEach(function(row){
            const matches = query === '' || (row.dataset.search || '').includes(query);
            row.hidden = !matches;
            if (matches) visible += 1;
        });

        if (lowStockVisibleCount) lowStockVisibleCount.textContent = String(visible);
        if (lowStockEmptySearch) lowStockEmptySearch.style.display = visible === 0 ? 'block' : 'none';
    }

    function openLowStockModal(trigger){
        if (!lowStockModal) return;
        const returnFocus = trigger?.closest('#notificationMenu') ? notificationButton : trigger;
        closeNotifications();
        if (lowStockSearch) {
            lowStockSearch.value = '';
            filterLowStockRows();
        }
        window.PharxmacoModal.open(lowStockModal, {
            className: 'open', trigger: trigger, returnFocus: returnFocus,
            initialFocus: lowStockModal.querySelector('[data-close-low-stock]')
        });
        lowStockModal.querySelector('.low-stock-list').scrollTo(0, 0);
    }

    function closeLowStockModal(){
        window.PharxmacoModal.close(lowStockModal);
    }

    document.querySelectorAll('[data-open-low-stock]').forEach(function(button){
        button.addEventListener('click', function(){ openLowStockModal(button); });
    });
    document.querySelectorAll('[data-close-low-stock]').forEach(function(button){
        button.addEventListener('click', closeLowStockModal);
    });
    if (lowStockSearch) lowStockSearch.addEventListener('input', filterLowStockRows);
    if (lowStockModal) {
        lowStockModal.addEventListener('click', function(event){
            if (event.target === lowStockModal) closeLowStockModal();
        });
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            if (lowStockModal && lowStockModal.classList.contains('open')) {
                closeLowStockModal();
                return;
            }
            if (sidebar.classList.contains('open')) closeSidebar();
            const restoreNotificationFocus = notificationMenu && notificationMenu.classList.contains('open');
            closeNotifications();
            if (restoreNotificationFocus) notificationButton.focus();
        }
    });

    /* ── Notification dropdown ── */
    const notificationWrap = document.getElementById('notificationWrap');
    const notificationButton = document.getElementById('notificationButton');
    const notificationMenu = document.getElementById('notificationMenu');

    function closeNotifications(){
        if (!notificationMenu || !notificationButton) return;
        notificationMenu.classList.remove('open');
        notificationButton.setAttribute('aria-expanded', 'false');
    }
    document.addEventListener('pharxmaco:close-notifications', closeNotifications);

    if (notificationButton && notificationMenu) {
        notificationButton.addEventListener('click', function(event){
            event.stopPropagation();
            const willOpen = !notificationMenu.classList.contains('open');
            closeNotifications();
            if (willOpen) {
                notificationMenu.classList.add('open');
                notificationButton.setAttribute('aria-expanded', 'true');
            }
        });

        notificationMenu.addEventListener('click', function(event){ event.stopPropagation(); });
        notificationButton.addEventListener('keydown', function(event) {
            if (event.key !== 'ArrowDown') return;
            event.preventDefault();
            if (!notificationMenu.classList.contains('open')) notificationButton.click();
            notificationMenu.querySelector('[role="menuitem"]')?.focus();
        });
        notificationMenu.addEventListener('keydown', function(event) {
            const items = Array.from(notificationMenu.querySelectorAll('[role="menuitem"]'));
            if (!items.length || !['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
            event.preventDefault();
            const index = items.indexOf(document.activeElement);
            const next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : (index + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
            items[next].focus();
        });
        document.addEventListener('click', function(event){
            if (notificationWrap && !notificationWrap.contains(event.target)) closeNotifications();
        });
        document.addEventListener('focusin', function(event){
            if (!notificationWrap.contains(event.target)) closeNotifications();
        });
    }

    /* ── Theme toggle and browser-only UI preferences ── */
    const themeToggle = document.getElementById('themeToggle');
    const html = document.documentElement;
    const uiSettingsKey = 'pharxmaco-ui-settings';

    function readUiSettings(){
        try {
            return Object.assign({
                theme: 'system', accent: 'blue', textSize: 'normal', density: 'comfortable',
                largeControls: false, reduceMotion: false, highContrast: false, stickyHeaders: false
            }, JSON.parse(localStorage.getItem(uiSettingsKey) || '{}'));
        } catch (error) {
            return {theme:'system', accent:'blue', textSize:'normal', density:'comfortable', largeControls:false, reduceMotion:false, highContrast:false, stickyHeaders:false};
        }
    }

    function applyUiThemePreference(settings){
        const systemDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        const isDark = settings.theme === 'dark' || (settings.theme === 'system' && systemDark);
        html.classList.toggle('dark', isDark);
        if (themeToggle) {
            themeToggle.setAttribute('aria-pressed', String(isDark));
            themeToggle.setAttribute('aria-label', isDark ? 'Switch to light mode' : 'Switch to dark mode');
            themeToggle.title = isDark ? 'Switch to light mode' : 'Switch to dark mode';
        }
        html.dataset.themePreference = settings.theme;
        html.dataset.accent = settings.accent || 'blue';
        html.dataset.textSize = settings.textSize || 'normal';
        html.dataset.density = settings.density || 'comfortable';
        html.classList.toggle('large-controls', Boolean(settings.largeControls));
        html.classList.toggle('reduce-motion', Boolean(settings.reduceMotion));
        html.classList.toggle('high-contrast', Boolean(settings.highContrast));
        html.classList.toggle('sticky-table-headers', Boolean(settings.stickyHeaders));
        try { localStorage.setItem('pharxmaco-theme', isDark ? 'dark' : 'light'); } catch (error) {}
        window.dispatchEvent(new CustomEvent('pharxmaco:ui-settings-applied', {detail: settings}));
    }

    applyUiThemePreference(readUiSettings());
    window.addEventListener('pharxmaco:ui-settings-saved', function(){
        applyUiThemePreference(readUiSettings());
    });
    if (themeToggle) {
        themeToggle.addEventListener('click', function(){
            const settings = readUiSettings();
            settings.theme = html.classList.contains('dark') ? 'light' : 'dark';
            try { localStorage.setItem(uiSettingsKey, JSON.stringify(settings)); } catch (error) {}
            applyUiThemePreference(settings);
        });
    }

    if (window.matchMedia) {
        const colorScheme = window.matchMedia('(prefers-color-scheme: dark)');
        const onColorSchemeChange = function(){
            const settings = readUiSettings();
            if (settings.theme === 'system') applyUiThemePreference(settings);
        };
        if (typeof colorScheme.addEventListener === 'function') colorScheme.addEventListener('change', onColorSchemeChange);
        else if (typeof colorScheme.addListener === 'function') colorScheme.addListener(onColorSchemeChange);
    }

    window.addEventListener('storage', function(event){
        if (event.key === uiSettingsKey || event.key === 'pharxmaco-theme' || event.key === null) {
            applyUiThemePreference(readUiSettings());
        }
    });


    /* ── Automatic search and filters ──
       Every GET filter form refreshes automatically. Text searches wait
       briefly after typing; dropdowns, dates, radio buttons, and checkboxes
       refresh almost immediately. Existing submit buttons stay available as
       a keyboard/no-JavaScript fallback. Add data-auto-filter="off" to opt out. */
    (function setupAutomaticFilters(){
        const forms = Array.from(document.querySelectorAll('form')).filter(function(form){
            return form.method.toLowerCase() === 'get' && form.dataset.autoFilter !== 'off';
        });
        if (!forms.length) return;

        const timers = new WeakMap();
        const composing = new WeakSet();

        function getStatus(form){
            let status = form.querySelector(':scope > .auto-filter-status');
            if (!status) {
                status = document.createElement('span');
                status.className = 'auto-filter-status';
                status.setAttribute('role', 'status');
                status.setAttribute('aria-live', 'polite');
                status.setAttribute('aria-atomic', 'true');
                form.appendChild(status);
            }
            return status;
        }

        function setStatus(form, message, type){
            const status = getStatus(form);
            status.textContent = message || '';
            status.className = 'auto-filter-status' + (message ? ' show' : '') + (type ? ' ' + type : '');
        }

        function clearInvalid(form){
            form.querySelectorAll('.auto-filter-invalid').forEach(function(control){
                control.classList.remove('auto-filter-invalid');
            });
        }

        function validateDateRanges(form){
            clearInvalid(form);
            const controls = Array.from(form.elements).filter(function(control){
                return control && control.name && control.name.endsWith('_from');
            });

            for (const from of controls) {
                const toName = from.name.slice(0, -5) + '_to';
                const to = form.elements.namedItem(toName);
                if (!to || !from.value || !to.value) continue;
                if (from.value > to.value) {
                    from.classList.add('auto-filter-invalid');
                    to.classList.add('auto-filter-invalid');
                    setStatus(form, 'Start date must be on or before the end date.', 'invalid');
                    return false;
                }
            }
            return true;
        }

        function submitFilter(form){
            timers.delete(form);
            if (form.classList.contains('auto-filter-submitting')) return;

            if (!validateDateRanges(form)) return;
            if (!form.checkValidity()) {
                setStatus(form, 'Complete or correct the highlighted filter before results can update.', 'invalid');
                return;
            }
            if (!navigator.onLine) {
                setStatus(form, 'You are offline. Reconnect, then change a filter or press the filter button.', 'offline');
                return;
            }

            form.classList.add('auto-filter-submitting');
            setStatus(form, 'Updating results…', '');
            if (typeof form.requestSubmit === 'function') form.requestSubmit();
            else form.submit();
        }

        function schedule(form, delay){
            const existing = timers.get(form);
            if (existing) window.clearTimeout(existing);
            clearInvalid(form);
            setStatus(form, 'Waiting for filter changes…', '');
            const timer = window.setTimeout(function(){ submitFilter(form); }, delay);
            timers.set(form, timer);
        }

        forms.forEach(function(form){
            const controls = Array.from(form.elements).filter(function(control){
                if (!control || !control.name || control.disabled) return false;
                if (control.dataset.autoFilterIgnore === 'true') return false;
                return !['hidden', 'submit', 'button', 'reset', 'file', 'image'].includes((control.type || '').toLowerCase());
            });
            if (!controls.length) return;

            form.classList.add('auto-filter-enabled');

            controls.forEach(function(control){
                const type = (control.type || '').toLowerCase();
                const isTypingControl = control.tagName === 'TEXTAREA' || ['text', 'search', 'email', 'tel', 'url'].includes(type);

                control.addEventListener('compositionstart', function(){ composing.add(control); });
                control.addEventListener('compositionend', function(){
                    composing.delete(control);
                    schedule(form, 550);
                });

                if (isTypingControl) {
                    control.addEventListener('input', function(event){
                        if (event.isComposing || composing.has(control)) return;
                        schedule(form, 550);
                    });
                    control.addEventListener('keydown', function(event){
                        if (event.key === 'Enter' && !event.isComposing) {
                            const pending = timers.get(form);
                            if (pending) window.clearTimeout(pending);
                        }
                    });
                } else {
                    control.addEventListener('change', function(){ schedule(form, 280); });
                }
            });

            form.addEventListener('submit', function(){
                const pending = timers.get(form);
                if (pending) window.clearTimeout(pending);
                timers.delete(form);
                form.classList.add('auto-filter-submitting');
                setStatus(form, 'Updating results…', '');
            });
        });
    })();

    /* Prevent accidental duplicate saves on CRUD forms. */
    document.querySelectorAll('form[method="post"]').forEach(function(form){
        form.addEventListener('submit', function(event){
            if (!form.checkValidity()) return;
            const button = form.querySelector('button[type="submit"]');
            if (!button || button.dataset.noSubmitLock === 'true') return;
            window.setTimeout(function(){
                if (event.defaultPrevented) return;
                button.disabled = true;
                if (!button.dataset.originalLabel) button.dataset.originalLabel = button.textContent.trim();
                button.textContent = button.dataset.busyLabel || 'Saving…';
            }, 0);
        });
    });

})();
</script>
</body>
</html>
